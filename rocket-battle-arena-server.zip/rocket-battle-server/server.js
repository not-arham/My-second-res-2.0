import express from "express";
import http from "node:http";
import cors from "cors";
import { Server } from "socket.io";
import { randomInt } from "node:crypto";

const app = express();
app.use(cors());
app.get("/", (_req, res) => res.json({
  name: "Rocket Battle Arena server",
  status: "online",
  message: "Socket.IO server is running"
}));
app.get("/health", (_req, res) => res.json({ ok: true }));

const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_ORIGIN?.split(",") ?? "*", methods: ["GET", "POST"] }
});

const rooms = new Map();
const PORT = Number(process.env.PORT || 3000);
const cleanName = value => String(value || "Pilot").trim().slice(0, 16) || "Pilot";
const roomCode = () => {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do { code = Array.from({length: 5}, () => chars[randomInt(chars.length)]).join(""); }
  while (rooms.has(code));
  return code;
};
const publicRoom = room => ({
  code: room.code,
  status: room.players.size === 2 ? "playing" : "waiting",
  players: [...room.players.values()].map(p => ({
    id: p.id, name: p.name, slot: p.slot, x: p.x, y: p.y,
    angle: p.angle, hp: p.hp, weapon: p.weapon, alive: p.hp > 0
  }))
});
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  if (room) {
    room.players.delete(socket.id);
    socket.leave(code);
    if (room.players.size === 0) rooms.delete(code);
    else io.to(code).emit("room:update", publicRoom(room));
  }
  socket.data.roomCode = null;
}

io.on("connection", socket => {
  socket.emit("server:ready", { ok: true });

  socket.on("room:create", ({ name } = {}, reply = () => {}) => {
    leaveRoom(socket);
    const code = roomCode();
    const room = { code, players: new Map(), shots: new Map() };
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), slot: 1,
      x: 110, y: 220, angle: 0, hp: 100, weapon: "Laser Gun"
    });
    rooms.set(code, room);
    socket.data.roomCode = code;
    socket.join(code);
    reply({ ok: true, room: publicRoom(room) });
  });

  socket.on("room:join", ({ code, name } = {}, reply = () => {}) => {
    const normalized = String(code || "").trim().toUpperCase();
    const room = rooms.get(normalized);
    if (!room) return reply({ ok: false, error: "Room not found." });
    if (room.players.size >= 2) return reply({ ok: false, error: "Room is full." });
    leaveRoom(socket);
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), slot: 2,
      x: 610, y: 220, angle: Math.PI, hp: 100, weapon: "Laser Gun"
    });
    socket.data.roomCode = normalized;
    socket.join(normalized);
    io.to(normalized).emit("room:update", publicRoom(room));
    reply({ ok: true, room: publicRoom(room) });
  });

  socket.on("player:state", (state = {}) => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!player) return;
    player.x = Math.max(15, Math.min(705, Number(state.x) || player.x));
    player.y = Math.max(15, Math.min(425, Number(state.y) || player.y));
    player.angle = Number.isFinite(state.angle) ? state.angle : player.angle;
    player.weapon = String(state.weapon || player.weapon).slice(0, 32);
    socket.to(room.code).emit("player:state", {
      id: socket.id, x: player.x, y: player.y,
      angle: player.angle, weapon: player.weapon
    });
  });

  socket.on("combat:fire", (shot = {}) => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!player || room.players.size !== 2 || player.hp <= 0) return;
    const x = Math.max(0, Math.min(720, Number(shot.x) || player.x));
    const y = Math.max(0, Math.min(440, Number(shot.y) || player.y));
    const angle = Number.isFinite(shot.angle) ? shot.angle : player.angle;
    socket.to(room.code).emit("combat:fire", {
      id: socket.id, x, y, angle,
      weapon: player.weapon,
      rocket: Boolean(shot.rocket),
      at: Date.now()
    });
  });

  socket.on("combat:hit", ({ targetId, damage } = {}, reply = () => {}) => {
    const room = rooms.get(socket.data.roomCode);
    const attacker = room?.players.get(socket.id);
    const target = room?.players.get(String(targetId));
    if (!room || !attacker || !target || attacker.id === target.id) return reply({ok:false});
    const amount = Math.max(1, Math.min(60, Math.floor(Number(damage) || 1)));
    target.hp = Math.max(0, target.hp - amount);
    io.to(room.code).emit("player:health", { id: target.id, hp: target.hp });
    if (target.hp === 0) io.to(room.code).emit("match:over", {
      winnerId: attacker.id, loserId: target.id
    });
    reply({ok:true, hp:target.hp});
  });

  socket.on("room:leave", () => leaveRoom(socket));
  socket.on("disconnect", () => leaveRoom(socket));
});

httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`Rocket Battle Arena server listening on ${PORT}`);
});
