# Rocket Battle Arena — 1v1 server starter

This is a real Node.js + Socket.IO backend starter. It creates private 5-character
room codes, supports two connected players per room, relays player state and shots,
and tracks basic player health.

## Run locally

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000/health` to check the server.

The Socket.IO endpoint is `http://localhost:3000`.

## Connect a browser client

Install the Socket.IO client in your game project:

`npm install socket.io-client`

Example:

```js
import { io } from "socket.io-client";
const socket = io("http://localhost:3000");

socket.emit("room:create", { name: "Player 1" }, result => {
  if (result.ok) console.log("Room code:", result.room.code);
});

socket.emit("room:join", { code: "ABCDE", name: "Player 2" }, result => {
  if (!result.ok) console.error(result.error);
});

socket.on("room:update", room => console.log(room));
socket.on("player:state", state => console.log("Opponent:", state));
socket.on("combat:fire", shot => console.log("Opponent fired:", shot));
socket.on("player:health", health => console.log("Health:", health));
socket.on("match:over", result => console.log("Winner:", result.winnerId));
```

For movement, send `player:state` with `{x, y, angle, weapon}`.
For shooting, send `combat:fire` with `{x, y, angle, rocket}`.
To report a hit, send `combat:hit` with `{targetId, damage}` and receive an acknowledgement.

## Deploy

Deploy this folder to a Node.js hosting provider that supports persistent WebSocket
connections (for example, a Node app host or VPS). Set `PORT` if required.
Set `CLIENT_ORIGIN` to your game's exact origin (comma-separated for multiple origins).

## Important

This is a backend starter, not a complete anti-cheat authoritative game server.
The current Rocket Battle Arena browser demo is not automatically connected to it.
The game client still needs Socket.IO integration, and hit validation should be moved
server-side before public competitive play. Localhost only works on the same device;
players on separate devices need the server deployed to a public host.
