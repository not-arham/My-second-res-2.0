import express from "express";
import http from "node:http";
import { Server } from "socket.io";
import { randomInt } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
const dir=path.dirname(fileURLToPath(import.meta.url));
const app=express(); app.use(express.static(path.join(dir,"public")));
app.get("/health",(_,res)=>res.json({ok:true,game:"Rocket Arena"}));
const server=http.createServer(app),io=new Server(server,{cors:{origin:"*"}});
const rooms=new Map(), makeCode=()=>{let c;do{c=Array.from({length:5},()=>"ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[randomInt(32)]).join("")}while(rooms.has(c));return c};
const snapshot=r=>({code:r.code,players:[...r.players.values()]});
function leave(s){const c=s.data.room;if(!c)return;const r=rooms.get(c);if(r){r.players.delete(s.id);if(!r.players.size)rooms.delete(c);else io.to(c).emit("room:update",snapshot(r));}s.leave(c);s.data.room=null;}
io.on("connection",s=>{
 s.on("room:create",({name="Pilot"}={},ack=()=>{})=>{leave(s);const c=makeCode(),r={code:c,players:new Map()};r.players.set(s.id,{id:s.id,name:String(name).slice(0,16),x:110,y:220,angle:0,hp:100});rooms.set(c,r);s.data.room=c;s.join(c);ack({ok:true,room:snapshot(r)});});
 s.on("room:join",({code,name="Pilot"}={},ack=()=>{})=>{const r=rooms.get(String(code||"").toUpperCase());if(!r)return ack({ok:false,error:"Room not found."});if(r.players.size>=2)return ack({ok:false,error:"Room is full."});leave(s);r.players.set(s.id,{id:s.id,name:String(name).slice(0,16),x:610,y:220,angle:3.14,hp:100});s.data.room=r.code;s.join(r.code);io.to(r.code).emit("room:update",snapshot(r));ack({ok:true,room:snapshot(r)});});
 s.on("player:state",v=>{const r=rooms.get(s.data.room),p=r?.players.get(s.id);if(!p)return;p.x=Math.max(15,Math.min(705,+v.x||p.x));p.y=Math.max(15,Math.min(425,+v.y||p.y));p.angle=+v.angle||0;s.to(r.code).emit("player:state",{id:s.id,x:p.x,y:p.y,angle:p.angle});});
 s.on("combat:fire",v=>{const r=rooms.get(s.data.room);if(r?.players.size===2&&r.players.has(s.id))s.to(r.code).emit("combat:fire",{id:s.id,...v});});
 s.on("room:leave",()=>leave(s));s.on("disconnect",()=>leave(s));
});
server.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("Rocket Arena server ready"));
