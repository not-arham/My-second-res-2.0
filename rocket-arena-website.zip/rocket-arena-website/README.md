# Rocket Arena

Responsive browser game starter with 2D bot battles, keyboard/touch controls, aiming and shooting, and Socket.IO private room codes for online 1v1.

## Run locally
Install Node.js 20+, then run:
1. `npm install`
2. `npm start`
3. Open `http://localhost:3000`

## Publish online
Deploy this folder to a Node.js host that supports persistent WebSocket connections (for example Render). Start command: `npm start`.

## Use rocketarena.io
Register `rocketarena.io` separately if it is available. Add it as a custom domain in your host and configure the DNS records the host provides.

## Notes
The project files are prepared but not deployed. Online room creation and player-state/fire relay are wired. This is a prototype, not an anti-cheat competitive backend; authoritative hit validation still needs to be added.
